# _u_map test program

Execute use cases for `struct _u_map` and display the results

## Compile and run

```bash
$ make test
```
